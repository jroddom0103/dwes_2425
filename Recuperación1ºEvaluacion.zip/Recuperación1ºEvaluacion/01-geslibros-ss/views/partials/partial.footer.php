<!-- Pie del proyecto -->
<footer class="footer mt-auto py-3 fixed-bottom bg-light">
    <div class="container">
        <span class="text-muted">© 2024
            Rodríguez Domínguez Juan Antonio - DWES - 2º DAW - Curso 24/25</span>
    </div>
</footer>