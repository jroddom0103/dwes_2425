<?php

    /*
        Creadenciales acceso a la base de datos

        Por seguridad este archivo debe estar protegido
    */

    // Defino las constantes de conexión

    define('SERVER', 'localhost');
    define('USER', 'root');
    define ('PASS', null);
    define('BD', 'geslibros');
    define('CHARSET', 'utf8mb4');
    define('COLLECTION', 'utf8mb4_unicode_ci');